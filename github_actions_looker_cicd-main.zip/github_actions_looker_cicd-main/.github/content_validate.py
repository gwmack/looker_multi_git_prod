"""Runs Content Validator."""
import looker_sdk
from looker_sdk import models
import configparser
import hashlib
import argparse
import csv

sdk = looker_sdk.init40()


def main():
    """Compare the output of content validator runs
    in production and development mode. Additional
    broken content in development mode will be
    outputted to a csv file.
    Use this script to test whether LookML changes
    will result in new broken content."""

    parser = argparse.ArgumentParser(description='Run content validator')
    parser.add_argument('--branch', '-b', type=str,
                        help='Name of branch you want to validate. If ommited this will use prod.')
    parser.add_argument('--project', '-p', type=str,
                        help='name of project to validate. This arg is required.')
    args = parser.parse_args()
    branch = args.branch
    project = args.project
    base_url = get_base_url()
    space_data = get_space_data()
    print("Checking for broken content in production.")
    broken_content_prod = parse_broken_content(
        base_url, get_broken_content(), space_data
    )
    checkout_dev_branch(branch, project)
    print("Checking for broken content in dev branch.")
    broken_content_dev = parse_broken_content(
        base_url, get_broken_content(), space_data
    )
    new_broken_content = compare_broken_content(broken_content_prod, broken_content_dev)
    if new_broken_content:
        print(new_broken_content)
        write_broken_content_to_file(new_broken_content, "new_broken_content.csv")
    else:
        print("No new broken content in development branch.")
    broken = len(new_broken_content)
    assert broken == 0


def get_base_url():
    """ Pull base url from looker.ini, remove port"""
    base_url = "https://profservices.dev.looker.com:19999"
    return base_url


def get_space_data():
    """Collect all space information"""
    space_data = sdk.all_spaces(fields="id, parent_id, name")
    return space_data


def get_broken_content():
    """Collect broken content"""
    broken_content = sdk.content_validation(
        transport_options={"timeout": 6000}
    ).content_with_errors
    return broken_content


def parse_broken_content(base_url, broken_content, space_data):
    """Parse and return relevant data from content validator"""
    output = []
    for item in broken_content:
        if item.dashboard:
            content_type = "dashboard"
        else:
            content_type = "look"
        item_content_type = getattr(item, content_type)
        try:
            id = item_content_type.id
            name = item_content_type.title
            space_id = item_content_type.space.id
            space_name = item_content_type.space.name
            errors = item.errors
            url = f"{base_url}/{content_type}s/{id}"
            space_url = "{}/spaces/{}".format(base_url, space_id)
        except AttributeError:
            print(item)
            print("has no id...")
            pass
        if content_type == "look":
            element = None
        else:
            dashboard_element = item.dashboard_element
            element = dashboard_element.title if dashboard_element else None
        # Lookup additional space information
        space = next(i for i in space_data if str(i.id) == str(space_id))
        parent_space_id = space.parent_id
        # Old version of API  has issue with None type for all_space() call
        if parent_space_id is None or parent_space_id == "None":
            parent_space_url = None
            parent_space_name = None
        else:
            parent_space_url = "{}/spaces/{}".format(base_url, parent_space_id)
            parent_space = next(
                (i for i in space_data if str(i.id) == str(parent_space_id)), None
            )
            # Handling an edge case where space has no name. This can happen
            # when users are improperly generated with the API
            try:
                parent_space_name = parent_space.name
            except AttributeError:
                parent_space_name = None
        # Create a unique hash for each record. This is used to compare
        # results across content validator runs
        unique_id = hashlib.md5(
            "-".join(
                [str(id), str(element), str(name), str(errors), str(space_id)]
            ).encode()
        ).hexdigest()
        data = {
            "unique_id": unique_id,
            "content_type": content_type,
            "name": name,
            "url": url,
            "dashboard_element": element,
            "space_name": space_name,
            "space_url": space_url,
            "parent_space_name": parent_space_name,
            "parent_space_url": parent_space_url,
            "errors": str(errors),
        }
        output.append(data)
    return output


def compare_broken_content(broken_content_prod, broken_content_dev):
    """Compare output between 2 content_validation runs"""
    unique_ids_prod = set([i["unique_id"] for i in broken_content_prod])
    unique_ids_dev = set([i["unique_id"] for i in broken_content_dev])
    new_broken_content_ids = unique_ids_dev.difference(unique_ids_prod)
    new_broken_content = []
    for item in broken_content_dev:
        if item["unique_id"] in new_broken_content_ids:
            new_broken_content.append(item)
    return new_broken_content


def checkout_dev_branch(branch, project):
    """Enter dev workspace"""
    sdk.update_session(models.WriteApiSession(workspace_id="dev"))
    sdk.update_git_branch(project_id=project,
                          body=models.WriteGitBranch(name=branch))


def write_broken_content_to_file(broken_content, output_csv_name):
    """Export new content errors in dev branch to csv file"""
    try:
        with open(output_csv_name, "w") as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=list(broken_content[0].keys()))
            writer.writeheader()
            for data in broken_content:
                writer.writerow(data)
        print("Broken content information outputed to {}".format(output_csv_name))
    except IOError:
        print("I/O error")


main()

